"""Run with python3 -m unittest discover -s tests from the skill folder."""
import copy
import importlib.util
import json
from pathlib import Path
import re
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("review_builder", ROOT / "scripts/render_review.py")
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)

class ReviewBuilderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name) / "task"
        shutil.copytree(ROOT / "examples", self.base)
        self.file = self.base / "review-data.json"
        self.data = json.loads(self.file.read_text(encoding="utf-8"))
        self.out = self.base / "review.html"

    def render(self):
        self.file.write_text(json.dumps(self.data, ensure_ascii=False), encoding="utf-8")
        builder.build(self.file, self.out)
        html = self.out.read_text(encoding="utf-8")
        block = re.search(r'<script id="review-data" type="application/json">(.*?)</script>', html, re.S).group(1)
        return html, json.loads(block)

    def test_embeds_exact_svg_and_unverified_evidence(self):
        _, data = self.render()
        self.assertEqual(data["concepts"][0]["svg"], (self.base / "icons/card-clock.svg").read_text(encoding="utf-8"))
        self.assertEqual(data["concepts"][0]["qa"], self.data["concepts"][0]["qa"])
        self.assertEqual(data["spec"]["grid"], 24)

    def test_text_cannot_terminate_json_script(self):
        attack = '</script><script>window.injected=true</script><b>ภาษาไทย</b>'
        self.data["title"] = attack
        html, data = self.render()
        self.assertNotIn(attack, html)
        self.assertEqual(data["title"], attack)

    def test_rejects_active_svg_and_does_not_write_output(self):
        file = self.base / "icons/card-clock.svg"
        file.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><script>alert(1)</script></svg>', encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "Unsupported SVG element"):
            self.render()
        self.assertFalse(self.out.exists())

    def test_rejects_source_escape(self):
        self.data["concepts"][0]["svgFile"] = "../outside.svg"
        with self.assertRaisesRegex(ValueError, "inside the data directory"):
            self.render()

    def test_optional_keyline_and_no_recommendation(self):
        self.data["recommendedId"] = None
        self.data["concepts"] = [self.data["concepts"][0]]
        del self.data["concepts"][0]["keylineFile"]
        _, data = self.render()
        self.assertIsNone(data["recommendedId"])
        self.assertIsNone(data["concepts"][0]["keylineSvg"])

    def test_rejects_unknown_recommendation_or_duplicate_ids(self):
        self.data["recommendedId"] = "does-not-exist"
        with self.assertRaisesRegex(ValueError, "recommendedId"):
            self.render()
        self.data["recommendedId"] = "card-clock"
        self.data["concepts"].append(copy.deepcopy(self.data["concepts"][0]))
        with self.assertRaisesRegex(ValueError, "unique lowercase"):
            self.render()

if __name__ == "__main__":
    unittest.main()
