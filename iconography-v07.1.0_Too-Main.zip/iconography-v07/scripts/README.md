# Scripts

## `render_review.py` — default HTML review builder

Uses Python 3.9+ standard library and the bundled HTML template. Read
[the data/build guide](../references/html-review-template.md) when delivering an
HTML comparison. This utility is independent of the legacy raster exporter below.

```sh
python3 scripts/render_review.py examples/review-data.json -o /tmp/icon-review.html
```

Replace example data with actual task output before delivery. The builder validates
data and SVG embedding, not icon geometry or comprehension claims.

> **v07 known limitation:** This legacy exporter is unchanged from v06.
> `fit_image` can alter alpha/color when padding translucent input, and
> `apply_corner_radius` replaces existing alpha. Do not use for production
> until these defects are repaired and target-platform output is validated.

Utility scripts for this skill. Nothing here runs automatically — invoke a
script only when the user's request actually calls for it.

---

## `icon_generator.py` — app/launcher icon export

Takes **one raster image** and writes the full Android + iOS **app icon** set:
every mipmap density, the Play Store icon, the complete
`AppIcon.appiconset/` with `Contents.json`, and optionally Android Adaptive
Icon foreground/background/XML.

### Scope — read this before reaching for it

This is for **app launcher icons**, not for the UI icon sets this skill
normally designs. A 24×24 outline icon inside a product never goes through
this script; it ships as SVG.

Use it when: the user wants a logo or app mark turned into the platform-required
launcher icon sizes.

Do **not** use it when: the deliverable is a UI icon or icon set for a design
system. Those stay as SVG on the project grid, and rasterizing them into
mipmap folders is meaningless.

### Prerequisite

```bash
pip install 'Pillow>=10.0.0' --break-system-packages
```

### SVG input needs rasterizing first

Pillow cannot open SVG. If the source is an SVG concept produced by this
skill, render it to a large PNG first (1024×1024 or larger, transparent
background), then feed that PNG to the script:

```bash
pip install cairosvg --break-system-packages
python3 -c "import cairosvg; cairosvg.svg2png(url='mark.svg', write_to='mark.png', output_width=1024, output_height=1024)"
```

Render at the final size or above — never upscale a small raster into the
1024 marketing slot.

### Run

```bash
python3 scripts/icon_generator.py INPUT.png -o OUTPUT_DIR
```

### Options

| Flag | Default | Notes |
|---|---|---|
| `-o`, `--output` | `output_icons` | Output directory |
| `--name` | `ic_launcher.png` | Android icon filename |
| `--mode` | `contain` | `contain` pads to fit, `cover` center-crops |
| `--background` | `#00000000` (transparent) | Padding color for `contain`; `#RRGGBB` or `#RRGGBBAA` |
| `--extra-sizes` | — | Extra square PNGs, e.g. `--extra-sizes 128 216 256` |
| `--corner-radius` | `0` | Percentage, 0–50; bakes rounded corners into the raster |
| `--android-adaptive` | off | Also emit adaptive foreground/background/XML |
| `--adaptive-background` | `#FFFFFFFF` | Adaptive icon background color |

### Choosing options

- **`contain`** for logos and marks that must not be cropped — the default, and
  the right answer almost every time for a brand mark.
- **`cover`** only when edge-to-edge composition matters more than preserving
  every pixel of the artwork.
- **`--corner-radius`** only on explicit request. iOS masks corners itself and
  Android adaptive icons are masked by the launcher, so baking corners in is
  usually wrong — it double-rounds.
- **`--android-adaptive`** only when the user actually needs adaptive resources.
  Note the script fills the background with a flat color; if the design calls
  for a patterned or gradient background layer, that has to be authored
  separately.
- Keep the source **square and ≥1024 px**, with the mark inside a safe area —
  Android adaptive masks crop aggressively toward the center.

### Output layout

```text
OUTPUT_DIR/
  android/
    mipmap-mdpi|hdpi|xhdpi|xxhdpi|xxxhdpi/   ic_launcher.png
    custom-128/ custom-216/ custom-1024/
    play-store/                              play_store_icon.png
    extra/                                   # only with --extra-sizes
    mipmap-anydpi-v26/                       # only with --android-adaptive
  ios/
    AppIcon.appiconset/
      *.png
      Contents.json
```

Deliver the whole `OUTPUT_DIR` (zip it if the user needs one file), and state
which mode and options were used.

> A standalone `app-icon-generator` skill wraps this same script with fuller
> reference docs. If both are installed, either is fine — don't run the export
> twice.
