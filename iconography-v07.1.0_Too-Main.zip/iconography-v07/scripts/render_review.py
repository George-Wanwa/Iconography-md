#!/usr/bin/env python3
"""Build an offline icon comparison from UTF-8 JSON and local SVG files.
Python standard library only. This checks packaging/input safety, not icon quality.
"""
import argparse
import copy
import json
import math
from pathlib import Path
import re
import sys
from urllib.parse import urlparse
import xml.etree.ElementTree as ET

STATUSES = {"verified", "provisional", "failed", "not_tested", "not_applicable"}
TAGS = {"svg", "g", "path", "rect", "circle", "ellipse", "line", "polyline", "polygon", "title", "desc"}
ATTRS = {"viewBox", "width", "height", "fill", "stroke", "stroke-width", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "fill-rule", "clip-rule", "opacity", "fill-opacity", "stroke-opacity", "transform", "d", "x", "y", "x1", "y1", "x2", "y2", "cx", "cy", "r", "rx", "ry", "points", "vector-effect", "id", "role", "aria-label", "aria-hidden", "focusable"}

def text(value, name, empty=False):
    if not isinstance(value, str) or (not empty and not value.strip()):
        raise ValueError(name + " must be a non-empty string")
    return value

def number(value, name, low=0, high=512):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not low < value <= high:
        raise ValueError(name + " is outside its allowed numeric range")
    return value

def texts(value, name):
    if not isinstance(value, list):
        raise ValueError(name + " must be an array of strings")
    return [text(v, name) for v in value]

def svg_file(value, base, grid):
    rel = Path(text(value, "SVG file"))
    path = (base / rel).resolve()
    if rel.is_absolute() or not path.is_relative_to(base) or path.suffix.lower() != ".svg":
        raise ValueError("SVG files must be relative .svg paths inside the data directory")
    source = path.read_text(encoding="utf-8")
    if "<!" in source:
        raise ValueError("Remove SVG declarations, comments and entities before packaging: " + str(rel))
    root = ET.fromstring(source)
    if root.tag != "{http://www.w3.org/2000/svg}svg":
        raise ValueError("SVG root needs the standard SVG namespace: " + str(rel))
    try:
        view = [float(v) for v in re.split(r"[\s,]+", root.get("viewBox", "").strip())]
    except ValueError:
        view = []
    if view != [0, 0, grid, grid]:
        raise ValueError("SVG viewBox must match 0 0 grid grid: " + str(rel))
    for node in root.iter():
        if not node.tag.startswith("{http://www.w3.org/2000/svg}") or node.tag.rsplit("}", 1)[-1] not in TAGS:
            raise ValueError("Unsupported SVG element in " + str(rel))
        for key, value in node.attrib.items():
            if key not in ATTRS or re.search(r"url\s*\(|javascript:|data:|https?:|[<>]", value, re.I):
                raise ValueError("Unsupported SVG attribute/reference in " + str(rel) + ": " + key)
    return source, path.name

def build(data_path, output):
    if output.suffix.lower() != ".html":
        raise ValueError("Output must use .html; do not overwrite JSON or SVG source files")
    base = data_path.resolve().parent
    data = copy.deepcopy(json.loads(data_path.read_text(encoding="utf-8")))
    if not isinstance(data, dict):
        raise ValueError("Review JSON must be an object")
    for key in ["title", "project", "original", "meaning", "english", "recommendation"]:
        text(data.get(key), key)
    for key in ["notice", "footerNote"]:
        text(data.get(key, ""), key, empty=True)
    spec = data.get("spec")
    if not isinstance(spec, dict):
        raise ValueError("spec is required")
    grid = number(spec.get("grid", 24), "spec.grid", high=128)
    spec["grid"] = grid
    text(spec.get("style"), "spec.style")
    if spec.get("stroke") is not None:
        number(spec["stroke"], "spec.stroke", high=grid)
    number(spec.get("clearance"), "spec.clearance", high=grid)
    for key, default in [("iconColor", "#597284"), ("darkIconColor", "#FFFFFF")]:
        spec[key] = spec.get(key, default)
        if not isinstance(spec[key], str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", spec[key]):
            raise ValueError("spec." + key + " must be a six-digit hex color")
    sizes = spec.get("previewSizes", [grid])
    if not isinstance(sizes, list) or not sizes:
        raise ValueError("spec.previewSizes must be a non-empty array")
    spec["previewSizes"] = list(dict.fromkeys([grid] + [number(v, "preview size", high=128) for v in sizes]))
    concepts = data.get("concepts")
    if not isinstance(concepts, list) or not 1 <= len(concepts) <= 12:
        raise ValueError("Provide 1–12 concepts per review page; split larger batches by concept family")
    ids = set()
    filenames = set()
    for c in concepts:
        if not isinstance(c, dict):
            raise ValueError("Each concept must be an object")
        for key in ["id", "name", "summary", "usageLabel"]:
            text(c.get(key), "concept." + key)
        if not re.fullmatch(r"[a-z0-9-]+", c["id"]) or c["id"] in ids:
            raise ValueError("Concept IDs must be unique lowercase kebab-case")
        ids.add(c["id"])
        c["svg"], c["filename"] = svg_file(c.pop("svgFile"), base, grid)
        if c["filename"] in filenames:
            raise ValueError("Clean SVG basenames must be unique for unambiguous downloads")
        filenames.add(c["filename"])
        keyline = c.pop("keylineFile", None)
        c["keylineSvg"], c["keylineFilename"] = svg_file(keyline, base, grid) if keyline else (None, None)
        obj = c.get("objects", {})
        if not isinstance(obj, dict):
            raise ValueError("objects must be an object ledger")
        text(obj.get("primary"), "objects.primary")
        text(obj.get("modifier", ""), "objects.modifier", empty=True)
        for key in ["units", "instances"]:
            value = obj.get(key)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError("Object counts must be positive integers")
        for key in ["pros", "risks"]:
            c[key] = texts(c.get(key, []), key)
        if not c["pros"] or not c["risks"]:
            raise ValueError("Each concept needs at least one pro and one risk/limitation")
        qa = c.get("qa", [])
        if not isinstance(qa, list) or not qa:
            raise ValueError("Each concept needs evidence rows, including untested checks")
        for item in qa:
            if not isinstance(item, dict):
                raise ValueError("Each QA row must be an object")
            text(item.get("check"), "qa.check")
            text(item.get("evidence"), "qa.evidence")
            if item.get("status") not in STATUSES:
                raise ValueError("Unknown QA status")
        c["sources"] = c.get("sources", [])
        if not isinstance(c["sources"], list):
            raise ValueError("sources must be an array")
        for item in c["sources"]:
            if not isinstance(item, dict):
                raise ValueError("Each source must be an object")
            text(item.get("label"), "source.label")
            address = urlparse(text(item.get("url"), "source.url"))
            if address.scheme != "https" or not address.netloc:
                raise ValueError("Sources must use absolute HTTPS URLs")
    if data.get("recommendedId") is not None and data["recommendedId"] not in ids:
        raise ValueError("recommendedId must match a concept, or be null")
    template = Path(__file__).resolve().parent.parent / "assets/icon-review.html"
    source = template.read_text(encoding="utf-8")
    marker = "__ICON_REVIEW_DATA__"
    if source.count(marker) != 1:
        raise ValueError("Template data marker missing or duplicated")
    payload = json.dumps(data, ensure_ascii=False, allow_nan=False).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    html = source.replace(marker, payload)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html, encoding="utf-8")
    return len(concepts)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data", type=Path, help="Review JSON; SVG paths resolve relative to this file")
    parser.add_argument("-o", "--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        count = build(args.data, args.output)
    except (OSError, ValueError, KeyError, TypeError, ET.ParseError) as error:
        print("Cannot build review: " + str(error), file=sys.stderr)
        return 1
    print(f"Created {args.output.resolve()} ({count} concepts; geometry and claims require separate review)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
