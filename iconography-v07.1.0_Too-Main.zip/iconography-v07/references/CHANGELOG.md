# Changelog — DX-Iconography

Version history for `SKILL.md`. The skill itself carries no changelog; read this
file only when you need to know what changed and why.

---

## 7.1.0 — Reusable HTML comparison template

- Add a self-contained review template, standard-library Python builder and a
  replaceable example dataset/SVG fixtures. HTML delivery now uses the template
  rather than newly authored page structure for every icon generation.
- Shared size/background controls, actual-size specimens and master-size UI rows,
  selected-concept details, optional supplied keyline and exact source SVG downloads.
- Add a data contract and safe SVG/JSON embedding checks. Missing evidence remains
  untested/provisional; generated pages do not imply verified icon geometry.
- Template works offline without loading another skill or external UI libraries.

## 7.0.1 — 24 px UI baseline and lighter outline starting weight

- Make 24×24 the primary UI design, preview and acceptance size. Include 16 px
  only for actual use or an explicitly requested stress test.
- Following the team's screenshot feedback, propose 1.5 px as the lighter starting
  stroke. Keep the inherited 2 px Figma value identified as historical; update
  the local TungNgern override and project index consistently. Team visual
  acceptance of the new 1.5 px value is still pending.
- Recalculate centerlines, ink fit and cap-aware cut endpoints when changing
  stroke. Preserve the default 1.5 px ink gap rather than reusing old endpoints.
- Add size/weight regression cases 15–16. No source screenshot or icon artwork
  was edited in this skill-only update; live Figma assets remain unverified.

## 7.0.0 — Team feedback: semantics, counting, overlap and evidence

- Interpret Thai meaning before selecting shapes. Preserve timing, negation,
  state and direction. Add the team's phrase `การชำระเงินให้ตรงเวลา`; expected
  interpretation remains a working interpretation until confirmed by the team.
- Separate semantic units from visible instances. Prefer one, default maximum
  two; do not hide independent meanings inside details or repeated-role objects.
- Define minimum ink clearance with cap-aware real cuts. Remove exact-everywhere
  distance, forced endpoint snapping and fixed surviving-edge percentage rules.
- Give fitting/centering/live-area geometry one owner; reconcile the project
  overlay and modifier sizes. Optical corrections cannot exceed the live area.
- Separate source convention, rendered checks, agent judgment and participant
  evidence. Add 14 evaluation cases, not claims of completed team tests.
- Reuse project context on edits; scale exploration and deliverables to the job.
- Remove the old doc-pen SVG as a compliance benchmark: its claims were not a
  validated geometry test. The unchanged source remains in the original v06 ZIP.
- Preserve original project tokens and legacy exporter. Mark known exporter
  alpha defects; repairs and platform export validation are outside this update.

## v06.0.1 — Frontmatter description trimmed (patch)

The `description` field was 1,423 characters and the installer rejects anything
over 1,024. Rewritten to 878 characters (903 counting the indented block) with
the same content: what the skill does, the rules it enforces, what it delivers,
and the full trigger list in Thai and English. No rule changes.

## v06.0 — Renamed from iconography-v03-2

Name change only; no rule changes. The skill is now `iconography-v06` so its
version reads on one line with the rest of the family instead of carrying a
`v03.2.x` sub-version. Everything below this entry describes the same skill
under its old names.

## v05.x (was v03.2.1) — Audit fixes (patch)

No rule changes. Applied the three fixes from the SKILL.md audit: the
"ask which project" rule now has a single owner (Workflow 1) and the Input,
Instructions and Reference sections cross-reference it instead of restating it;
the Expected Output list is renumbered 1–8 with no lettered insertion; and the
modifier-size wording is now "40–55 % of the primary's **long side**" in both
SKILL.md and composition ref §C.1, replacing the old "bounding box" phrasing
that gave a different number for landscape and portrait primaries. Also added
the Author / Editor line, the worked Example section, and the conciseness rule
in Voice, and moved this changelog out of SKILL.md.

## v05.x (was v03.2) — Language interpretation, 2-object composition, keyline discipline

Everything below is additive on top of v03.1.

### 1. Requests in Thai are interpreted, not translated
Every non-English request is converted into an English concept brief
(`Concept: / Objects: / Intent:`) before research or drawing, and the
Thai → English mapping is reported back so a misreading can be caught. Research
queries and all asset names are English-only.
→ composition ref §A

### 2. Objects are counted explicitly, and the ceiling is 2
One primary plus at most one modifier (document + pen, wallet + plus). Details,
internal lines, badge plates and repeated copies of one thing don't add to the
count. A concept that seems to need three is absorbed, replaced with one
established symbol, trimmed, or split into two icons.
→ composition ref §B

### 3. Overlaps get a real knockout gap — one number everywhere
`grid ÷ 16` (**1.5 px on a 24 px grid**) of white between the two inks,
identical at a crossing, at the modifier's tip approaching a line, at interior
details and at parallel runs, so the channel around the modifier is a constant
width. Cut ends hug the modifier; no edge of the primary may be deleted.

*Tuning history:* started at 4 px measured along the back path, which left cut
ends floating in empty space at shallow crossings; changed to a perpendicular
ink-to-ink measure at 2 px, then to **1.5 px** — 2 px still read as a hole at
24 px because the visible break along a curved modifier is far longer than the
clearance itself.
→ composition ref §C.3

### 4. Every combined icon must pass a six-point comprehension check
One-word, global recognition, 16 px squint, collision, reversal, convention.
Failing the first three means redraw or drop back to a single object.
→ composition ref §D

### 5. Four keylines, and the primary is fitted to one of them
Circle (ทรงกลม) · Square (สี่เหลี่ยมจัตุรัส) · Horizon (สี่เหลี่ยมผืนผ้าแนวนอน) ·
Vertical (สี่เหลี่ยมผืนผ้าแนวตั้ง), with exact geometry on a 24 grid. The primary
is **sized to** its keyline, not merely placed inside it, and is centred on
(12, 12); with a modifier that sits outside or across its edge, the primary is
fitted to that keyline **inset 2 px on every side** and the ring that opens is
the modifier's room. Only the modifier moves. Nothing in the icon leaves the
20 × 20 live area.
→ global ref §1.1a, §1.1a-1, §1.1a-2, §1.1b, §1.1c

### 6. Every generation ships a keyline overlay
`[name]-keyline.svg` per icon plus the same overlay in the HTML summary, so the
fit, the centring and the containment are visible rather than asserted.
→ SKILL.md Expected Output 2

---

## v03.1 — Magnific research + HTML summary
Added the Magnific style-research step before drawing, and made a single
self-contained HTML summary page a mandatory deliverable on every job.

## v03 — Single global reference
Replaced per-brand reference files with one global reference file plus a
`projects/` folder, and made the skill ask which project to load before every
job.
