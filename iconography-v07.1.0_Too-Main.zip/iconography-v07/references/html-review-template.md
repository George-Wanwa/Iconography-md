# Reusable HTML Review Template

Read whenever this skill delivers a new or updated HTML comparison. Use the
bundled template; do not redesign the page or rebuild its CSS per generation.
Explicit user layout requests can override it. The template needs no separate
design skill, package install, frontend framework, network service or font CDN.

## Build

1. Author clean SVGs and separate keyline SVGs under the task's output folder.
   The template does not draw icons, change their stroke weight, add keylines,
   measure geometry, verify recognition, or fabricate QA results.
2. Create `review-data.json` next to them. Start from the shape of
   [examples/review-data.json](../examples/review-data.json), replacing all sample
   copy, SVG paths, recommendations and evidence with this task's actual data.
   The example is a template demonstration, not an approved icon set.
3. Run from any working directory, using the installed skill's actual path:

```sh
python3 <skill-folder>/scripts/render_review.py <output-folder>/review-data.json -o <output-folder>/icon-review.html
```

Python 3.9+ and its standard library suffice. SVG paths are relative to the
JSON's directory and must remain inside it. Generated HTML embeds all SVGs and
works offline. Source citations are ordinary external links, not page dependencies.
Deliver HTML plus the separate SVGs; keep the data JSON if further revisions
are expected. For an edit, update the data and affected SVGs, then regenerate.

## Data contract

Use the example for exact JSON syntax. Required top-level strings:
`title`, `project`, `original`, `meaning`, `english`, `recommendation`.
Optional `notice` and `footerNote` describe real limitations or review context.
`recommendedId` is a concept ID or null; absence/null means no recommendation.
The initial detail panel shows the recommendation, otherwise the first concept.

`spec`:

- `style`: human-readable style name.
- `grid`: default 24; all SVG viewBoxes must equal `0 0 grid grid`.
- `stroke`: actual authored weight at the master size, or null for filled art.
- `clearance`: intended gap; its presence is a spec, not proof it was measured.
- `previewSizes`: default `[24]`; include only requested/useful additional sizes.
  Do not add 16 just because the template supports other sizes.
- `iconColor`, `darkIconColor`: resolved six-digit hex preview values, default
  `#597284` / `#FFFFFF`. Preserve `currentColor` in authored SVGs where appropriate.

Each `concepts` entry contains:

- Unique kebab-case `id`; `name`, `summary`, `usageLabel` in the user's language.
- `svgFile` and optional `keylineFile`, pointing to actual SVG files. Use unique
  clean filenames. Missing keyline disables its toggle/download; still deliver
  overlays when the icon task requires them.
- `objects`: `primary`, `modifier` (empty string for none), `units`, `instances`.
- Non-empty string lists `pros` and `risks`. The first risk is the concise
  comparison note; put longer caveats in subsequent entries.
- Non-empty `qa`: rows with `check`, `status`, `evidence`. Status is one of
  `verified`, `provisional`, `failed`, `not_tested`, `not_applicable`. Every verified
  claim needs evidence and scope; the renderer checks syntax, not truth.
- `sources`: list of `{ "label": "...", "url": "https://..." }`, or `[]`.

## Stable layout and interactions

- Header: project, semantic title/brief, real spec, download for selected concept.
- Shared toolbar: comparison size and light/dark preview surfaces. Page chrome
  stays light. The UI usage row always keeps the master size (normally 24 px).
- Flat comparison board: radio selection, actual-size specimen, contextual row,
  one concise risk. One to three columns on desktop; two/tablet; one/mobile.
- Recommendation strip stays tied to the recommended concept even if a different
  concept is selected. Download and details follow the selected concept.
- Detail inspector: explicitly labeled enlarged construction (192 CSS px),
  optional supplied keyline, object ledger, expandable QA/brief/sources.
- Downloads preserve the source SVG, not the preview DOM or the current zoom.
  Changing size/background never changes exported geometry, color tokens or stroke.
- Native radio buttons, selects, buttons and disclosures support keyboard use.
  Do not add inert actions, decorative metrics or duplicate size galleries.

The SVG validator supports basic inline geometry only: svg/g/path/rect/circle/
ellipse/line/polyline/polygon/title/desc. It rejects scripts, styles, external
resources, masks and unsupported elements/attributes rather than silently
changing the artwork. Export simpler production paths if necessary. If a user
explicitly needs complex SVG features, make a deliberate renderer change and
verify it; do not bypass validation or paste untrusted markup into the template.

## Verify the actual delivery

Open generated HTML, not the unpopulated asset file. Confirm actual 24 px size,
selection/details, background, supplied keyline, and that downloads match the
selected source SVG. Inspect desktop and narrow/mobile widths for overflow and
Thai line breaks. Test one/four/five concepts when changing layout code. Report
any missing browser check. Existing QA rows must not become verified simply
because HTML generation or browser tests passed.
