# Convention Research — Libraries and Optional Magnific

Read when researching candidate metaphors. Start with the actual project icon
inventory. For international convention evidence, inspect matching icons in
established libraries appropriate to the task, such as Material Symbols,
Feather, EVA or Carbon. Use official sources and the actual item, not a homepage.

1. Search the **meaning** from the brief with English synonyms. Keep important
   qualifiers: `pay on time`, `payment due date`, not only `money` or `clock`.
2. Record source, actual icon name/link, depicted units, meaning/label and what
   differs from the requested concept. When global familiarity matters, compare
   more than one independently maintained library if available. Repeated copies
   of the same stock asset are not independent evidence.
3. Compare competing meanings. A clock attached to a payment object could signal
   pending, history or scheduling; do not claim it proves punctual payment.
4. Use stock surfaces such as Magnific as supplementary visual exploration.
   Discover current tools/pages instead of assuming the old v06 tool names or
   URLs still exist. No connector setup is required to complete ordinary research.
5. AI generation is optional exploration only when within the user's scope and
   available permissions/cost constraints. Its output is not evidence that an
   international convention exists. Do not generate solely to satisfy research.
6. Draw original geometry matching the family. Research availability, licensing
   and tool capabilities may change: verify current official terms when reusing
   an asset. Redrawing/tracing alone is not a blanket license exemption.
7. If sources are unavailable, record what could not be checked, use the local
   inventory and provide provisional alternatives. Never invent search results.

Suggested evidence row:
`Source/icon | observed meaning | units | relevance to brief | possible confusion`.
Evidence supports a design judgment; it cannot replace responses from the
intended audience when claiming user comprehension.
