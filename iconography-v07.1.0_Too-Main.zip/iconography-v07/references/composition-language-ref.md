# Language, Object Count, Overlap and Comprehension

Read §A before choosing a metaphor, §B before composition, §C for combining
units, and §D for review. Numeric defaults are local design conventions, not
universal laws of human perception.

## A. Thai → intended meaning → English brief

### A.1 Interpret meaning before drawing

1. Preserve the original text. Normalize spelling only when the intended word
   is clear. Separate the instruction to the assistant from the represented
   action: in `ช่วยทำไอคอนคืนเงินหน่อยครับ`, the icon means refund, not create.
2. Parse by meaning, not word order: action, target, state, timing, direction,
   qualifier, named entities and use context. Preserve `ไม่`, `ยังไม่`, `ห้าม`,
   `ยกเลิก`, `แล้ว`, `รอ`, `ชั่วคราว`, `ตรงเวลา` and other meaningful qualifiers.
3. Read compounds as units. `ใบเสร็จ` means receipt; `ใบ` is a classifier in
   `ใบเสร็จหนึ่งใบ` but means leaf within `ใบไม้`. Never strip classifiers or
   politeness by blind text substitution. Preserve expressed plurality such as
   `หลาย`, `ทั้งหมด`, `กลุ่ม`. Do not infer extra objects from grammatical words.
4. Treat `ถุงเงิน` and `เป๋าตัง` as product names when context identifies them as
   such. Do not turn a named product into a literal object. If a literal money
   bag is explicitly requested, preserve that request instead.
5. Paraphrase in Thai, translate the meaning into English, then compare it back
   against the original: same action, target, state, timing, direction and
   qualifier? Do not put proposed shapes in the semantic brief yet. Unknown
   screens/components stay unspecified, not invented.
6. Proceed with a stated assumption when context reasonably resolves meaning.
   Ask one targeted question when plausible readings imply different operations
   or states. Do not hide semantic ambiguity among alternative visual concepts.

Working brief (shorten in chat):

```text
Original: การชำระเงินให้ตรงเวลา
Meaning (TH): ชำระเงินภายในกำหนด ไม่ล่าช้า
Concept (EN): pay on time / pay by the due date
Action / target / timing: pay / payment / by its due date
Role: unspecified; wording expresses an objective, not proof of completed payment
Uncertainty: screen and whether it is a CTA, benefit, or status are unspecified
```

This is a real phrase supplied by the team; the above intended interpretation
is the working interpretation, not a team-confirmed expected answer. Preserve
the timing requirement during design. `payment` alone loses meaning; `pending
payment`, `scheduled payment`, `automatic payment`, `payment reminder`, and
`payment completed` each add/change meaning that the phrase did not establish.

For this case, a payment symbol + clock is only a candidate: it may suggest
pending payment. A calendar may suggest scheduling and a check may suggest paid.
Compare those interpretations before recommending an icon. A visible label
`ชำระตรงเวลา` can carry precision if no unlabeled metaphor communicates both
payment and punctuality. If a final state-specific asset is required, clarify
whether the UI asks the user to pay or reports that payment occurred on time.

### A.2 Contrastive examples

| Phrase | Preserve | Avoid |
|---|---|---|
| เช็คยอดเงิน | check account balance | cheque as paper |
| ฝากเช็ค | deposit a cheque | checkmark / verify |
| บันทึกการแก้ไข | save changes | download without workflow evidence |
| ดาวน์โหลดสลิป | download receipt | generic save changes |
| ผูกบัญชี | link account | tie a knot |
| ยกเลิกผูกบัญชี | cancel linking or unlink; resolve using context | silently choosing one |
| ปิดบัตรชั่วคราว | temporarily freeze/disable card | close dialog / permanently close account |
| ยังไม่ชำระ | unpaid | failed payment |
| ชำระไม่สำเร็จ | payment failed | unpaid with no failed attempt |
| รับเงิน / โอนเงินออก | receive / send money | identical direction |
| ประวัติรายการ ในหน้าการเงิน | transaction history | biography |

These extra examples are synthetic; they do not prove coverage of Thai usage.
Do not use letters to conceal an unclear metaphor. Explicitly requested currency
marks, typography icons and brand assets need audience/legibility judgment, not
a universal ban on letters. Explain the meaning in Thai; English supports
cross-library search and filenames, not user understanding by itself.

## B. How objects are counted

### B.1 Semantic units versus visible instances

The budget counts **independently meaningful visual units**, not paths, layers,
English words or strokes. Also report **visible instances**, so repetition does
not hide density. Removing anatomy leaves the same subject less detailed;
removing a modifier changes its action/state. Inside placement and boolean union
do not make an independent mark into anatomy.

| Drawing | Semantic units | Instances / reason |
|---|---:|---|
| Document, text lines, folded corner | 1 | 1 document; lines/fold are anatomy |
| Document + pen | 2 | document + edit modifier |
| Document containing checkmark | 2 | check adds state even inside the document |
| Wallet + plus on plain circular plate | 2 | plate only supports the plus badge |
| Wallet + currency coin + plus | 3 | coin has independent money meaning |
| Three people as a group | 1 group | 3 people; report repetition and density |
| Person → person | 3 | sender + direction + recipient have different roles |
| QR code + scan brackets | 2 | code + scanning modifier, even when familiar |
| Bell + ringing marks | 1 | ringing marks are the bell's motion detail |
| Bell + slash | 2 | slash changes state to disabled |

Ledger example:

```text
Primary: document
Modifier: pen → edit
Anatomy: folded corner and text lines
Semantic units: 2; visible instances: 2
Why not one: this context must distinguish edit document from view document
```

### B.2 Recommended budget

For functional UI icons, **prefer 1; default maximum 2 semantic units** (primary
+ one modifier). This is the skill's default, not an international standard.
Explicit user/project exceptions are possible; retain the same counting method.
Use the fewest repetitions that communicate a group and review actual-size density.

If a draft has 3+ units, try one established metaphor preserving the full intent;
remove redundant decoration; or retain the essential pair with a visible label.
Never remove a required state merely to pass the budget. Never relabel a third
meaning as detail. Propose splitting only when the request describes separate
functions. If meaning still needs 3+ units, explain the tradeoff and propose a
scoped exception or illustrative treatment rather than silently changing scope.

## C. Placement and cutting overlaps

### C.1 Composition

Global §1 owns primary fit, centering and containment. Start with that primary;
place the modifier around it, usually bottom-right when consistent with the
family. Preserve meaningful direction. Choose detached, contained or overlapping
by legibility; keep sibling relationships consistent.

Start modifier size at **40–55% of the primary's actual long ink dimension**:
a 16 px primary gives 6.4–8.8 px. This is a starting range; justify adjustments
with size inspection. Outline modifiers keep the family's stroke weight.
Name front and back objects; the action/state modifier normally sits in front.

### C.2 Gap definition

Default `g = grid/16` (1.5 px at 24), unless the project overrides it. Measure
nearest distances between rendered **ink boundaries**, including caps, joins
and transforms; not between centerlines.

- Detached/contained: nearest unrelated inks stay at least g apart.
- Overlap: trimmed ends sit near g from the front ink, avoiding floating breaks.
- Distant parts need not be exactly g apart. Check crossing points, tips, cut
  ends, interior lines and parallel runs; do not equalize all negative space.
- Report numerical precision when measuring. Do not claim exact clearance from
  an enlarged screenshot. Fractional endpoints are allowed when needed for g.

### C.3 Construct real geometry

Use available vector-editor/geometry operations, or analytic geometry for simple
shapes. Do not claim an operation was performed unless it was.

1. Keep a working copy; account for transforms. Identify the front silhouette,
   including the area it should occlude. Decide whether rear ink should show
   through a hollow badge; do not leave it visible accidentally.
2. Expand the front silhouette outward by g to create a temporary exclusion
   shape. Use an appropriate round offset, not an enlarged bounding rectangle.
3. For editable rear strokes, split and remove hidden segments; retreat endpoints
   for their cap shape. A round-capped rear endpoint must be g + half its stroke
   width from front ink. Re-measure after adding caps.
4. Alternatively, outline strokes and subtract the exclusion from the rear ink.
   Boolean subtraction alone does not preserve round terminals. Rebuild cut ends
   when the family requires them, then re-measure. Closed fill contours may
   represent an open-looking stroke; editable open stroke paths need not close.
5. Trim affected interior details too. Preserve defining corners and silhouette;
   remove unnecessary stubs instead of leaving noisy fragments.
6. Delete construction geometry. Ship actual empty space, not a background-color
   patch. Bake temporary masks into paths; no remaining mask/filter/halo stroke
   substitutes for the cut in this delivery workflow. Do not cut the front object.
7. Inspect on light/dark backgrounds at intended sizes. Reposition or simplify
   when the primary loses recognition. After two unsuccessful geometric revisions,
   try another composition/metaphor; report unresolved limitations rather than
   iterating indefinitely or asserting success.

Analytic sanity check for collinear round-capped ends:
`endpoint distance = g + back_stroke/2 + front_stroke/2`.
At two 1.5 px strokes and g=1.5, the endpoint distance is 3 px.
If the family explicitly uses two 2 px strokes, it is 3.5 px. Recalculate when
stroke width changes instead of reusing old cut endpoints. For oblique
strokes/curves use nearest boundary distances, not that number as a universal
x/y offset. Blind whole/half-pixel snapping can destroy a computed gap.

## D. Is the combined meaning understood?

Keep the semantic brief fixed when comparing visual alternatives. Check every
multi-unit candidate and compare a one-unit candidate when viable.

| Check | Method / evidence | Revise when |
|---|---|---|
| Intended meaning | Read without label, compare action/target/state/timing to brief; identify self-review | Wrong operation or lost qualifier |
| International convention | Inspect actual matching icons in relevant established libraries; record names/links and differences | Sources support another meaning or unexplained local cue |
| Small-size legibility | Render actual intended sizes, inspect units and separation | Modifier disappears, cuts look broken, units merge |
| Collision | Compare actual inventory, including nearest opposite states | Confusable with another action/state |
| Role reversal | Compare swapped subject/modifier while preserving meaning | Modifier dominates or subject is wrong |
| Necessity | Remove modifier and compare meaning in actual UI context | Only decoration or more ambiguity remains |

Use results with evidence scope:

- **Verified:** performed check with measurements, renders, source examples or
  participant responses. Say which kind; verified convention is not verified users.
- **Provisional:** designer/agent judgment; state reasoning and missing proof.
- **Failed:** observed mismatch/unreadability; revise or reject.
- **Not tested / not applicable:** state why. Missing inventory is not a pass.

International examples support plausibility, not proof of global comprehension.
AI-generated imagery and model opinions are not participant responses. A local
symbol can suit a specified local audience; record that boundary instead of
automatically erasing its meaning. A library homepage does not support a specific
metaphor; inspect the icon. Never fabricate a measurement, source or respondent.

### D.1 Lightweight team test when requested

Prepare unlabeled candidates at intended size, randomize order, and ask people
independently what action/state each represents. Record free answers before
showing labels. Test again in the real UI context as a separate condition.
Include intended non-Thai audiences for an international exploration. Record
language/context, sample size, exact counts and recurring wrong meanings.
Agree a practical acceptance criterion before interpreting results; small
convenience samples do not prove universal recognition. Do not contact anyone
without authorization. Preparing a test sheet is not conducting a user test.
