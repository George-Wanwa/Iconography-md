# Global Icon Design Defaults

Local baseline, subordinate to the user's/project's explicit rules. Geometry
rules belong here; language, counting, trimming and comprehension belong in
[composition-language-ref.md](composition-language-ref.md).

## 1. Grid, keylines and containment

Default canvas and UI acceptance size **24×24 px**, live area x/y 2–22,
outline starting stroke **1.5 px at 24 px**, round cap/join.
Color uses `currentColor` resolved by the host's project token. Filled/duotone
styles follow their family rather than mechanically adding an outline stroke.

The 1.5 px choice is a local starting point following team feedback that 2 px
looked too heavy in small composite icons; it is not a universal UI standard or
a completed comparison test. Keep primary and modifier at the same weight.
If 1.5 px looks too light in the actual family, compare 1.75 px at the same 24 px
size. Use 2 px when explicitly required or supported by the family comparison,
not as an automatic minimum. Do not migrate unrelated existing assets.

When changing stroke width, recalculate centerlines, caps, keyline ink bounds
and cut endpoints. Keep the specified ink clearance; changing `stroke-width`
alone can leave over-wide cuts or a primary that no longer fits its guide.

| Guide | 24-grid ink target | Choose for |
|---|---|---|
| Circle | diameter 20, center (12,12) | round/radial subjects |
| Square | 18×18, x/y 3–21 | near-square subjects |
| Horizon | 20×16, x 2–22, y 4–20 | wide subjects |
| Vertical | 16×20, x 4–20, y 2–22 | tall subjects |

Scale grid geometry by grid/24 for another master size. Stroke scaling follows
the project, which may keep a fixed width. A diamond may be an optical guide;
these four are the baseline fitting choices. Existing project families can
specify different guides. Do not misrepresent these defaults as sourced Figma data.

Fit the primary to the appropriate keyline, preserving aspect ratio. Touch the
dominant available extent; the other dimension may be smaller. Do not require
its bounding box to equal both keyline dimensions (a card must not be stretched).
For an outside/overlapping modifier, begin with the keyline inset 2 px per side
(scaled with grid). For a contained modifier, the full primary fit may work.

Center the primary's **pre-cut silhouette** on (grid/2, grid/2). A knockout can
change the remaining ink bounds; do not recenter the cut shape to chase those
bounds. Keep this primary anchor when placing the modifier. Combined mass may
be asymmetric; compare it with siblings rather than automatically translating
both objects. If a project explicitly specifies whole-icon optical alignment,
use that instead and state the departure from this default.

**The live area is the hard outer boundary for all ink. The keyline is a primary
fitting guide, not the outer boundary for the modifier.** Move/resize the modifier
or change composition when containment fails; do not silently scale both objects
away from the specified fit. If no composition works, revisit the metaphor.

Optical corrections improve perceived weight within the available room; they
are not mandatory percentage enlargement. A diameter-20 circle already fills
the 20-wide live area and cannot be enlarged without changing that constraint.
Prefer family consistency and inspect at true size. Keep a record of justified
departures; do not claim exact mathematical centering and a different optical
offset simultaneously.

Prefer crisp straight axes. Curves, diagonals and computed cut endpoints may
use fractional coordinates. Blindly snapping all anchors/control points to whole
or half pixels distorts shapes and gaps.

## 2. Style and vector hygiene

- Match the existing family: stroke, caps, joins, corner treatment, visual weight,
  outline/filled state relationship and naming. Avoid unnecessary interior detail.
- Preserve the requested style. Derive variants only when requested or useful.
- SVG is the default UI deliverable: correct `viewBox`, minimal useful paths,
  no editor debris, no invisible leftover construction. Use genuine knockout
  geometry per composition §C. Open strokes stay open; filled contours close.
- Keep shipping SVG separate from the construction overlay. The overlay shows
  live area, active keyline, pre-cut primary anchor/fit and final measured ink
  bounds. Distinguish computed measurements from approximations.
- Keep Figma component naming separate from portable filenames. Project color
  tokens belong in the host/preview mapping; SVG uses `currentColor` where suitable.

## 3. Meaning, accessibility and family context

Choose a metaphor for the requested operation/state, not a literal illustration
of every noun. Use the smallest set of semantic units preserving intent.
An icon can need a visible label to communicate precise business semantics.
Keep the timing/state qualifier in the brief even when a label carries it.

Do not rely on color alone for state. Check shape differences and contrast on
the actual host backgrounds; a token name is not proof of contrast. Avoid
unnecessary gender/religious stereotypes. Culturally specific subjects are valid
when the task calls for them; identify the intended audience honestly.

Inspect **24 px at 100% display scale first**, including an actual UI context,
then other requested production sizes. Inspect 16 px only when used or explicitly
requested; a 16 px variant may need its own simplified geometry. Do not thicken
the default 24 px icon to satisfy an unrequested 16 px stress test. Label an
enlarged view as construction, not actual size. Compare siblings for weight,
duplication and semantic collisions.
Existing shipped icons are evidence, not permission to modify unrelated assets.

## 4. Delivery checklist

Record result, method and evidence; use composition §D's status vocabulary.

- Meaning matches the brief, including negation/state/timing/direction.
- Object ledger separates semantic units, anatomy and repeated instances.
- Primary fit follows active keyline; all final ink is inside the live area.
- Gap construction accounts for caps/joins/transforms and preserves recognition.
- Requested size rendering and light/dark background inspection performed.
- Stroke/style/color/naming match the family; vector paths are clean.
- Actual inventory checked, or collision/drift explicitly not tested.
- Multi-unit comprehension reviewed without invented global-user claims.
- Clean SVG, overlay and requested comparison artifacts delivered.
