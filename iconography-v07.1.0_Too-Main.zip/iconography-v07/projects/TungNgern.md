# Design System — TN App Components

> **Source:** [Figma — TN / App Components → 📐Design System](https://www.figma.com/design/IsOuXy53Gs5U3Oeb6kVmtK/TN---App-Components?node-id=1464-13997)
> **Node:** `1464:13997`
> **Last synced:** 2026-07-21 (inherited snapshot; not re-fetched for v07)
> **v07 note:** Object budget, clearance, modifier sizing and fitting rules below are local skill policies revised from team feedback. Other project tokens remain the inherited snapshot.

This document captures the design tokens (color, typography, effects, spacing), icon style, and illustration style declared as Figma Variables and components in the file above. It serves as the single source of truth shared between Design and Engineering.

---

## 1. Overview

- **Primary font family:** Kanit (all UI), Roboto (G-Board / keyboard mock only)
- **Primary brand color:** Blue Primary — `#0CA6DF`
- **Semantic colors:** Green Success / Yellow Caution / Orange Warning / Red Critical
- **Neutral scale:** UI/00 → UI/07 (white to near-black) for backgrounds, borders, and text
- **Project colors:** Per-service colors (PromptPay, G-Wallet, KLK, GLO, etc.), kept separate from the core palette
- **Icons:** Feather + EVA foundation, 24 px default UI size; new local concepts start at 1.5 px stroke per §6.1. The inherited library snapshot recorded 2 px.
- **Illustrations:** Semi-flat / soft 3D, 240×168 landscape and 168×168 square

---

## 2. Color tokens

### 2.1 Neutral / UI

| Token | Value | Usage |
|---|---|---|
| `UI/00 White` | `#FFFFFF` | Primary background, surface |
| `UI/01 Light BG` | `#F1F7F9` | Secondary background, section background |
| `UI/02 Disabled BG` | `#E3EDF0` | Disabled button / field background |
| `UI/03 Border, Line` | `#D1DDE2` | Borders, dividers |
| `UI/04 Disabled Text` | `#92B1C1` | Disabled text, placeholder |
| `UI/05 Graphics, Large AA Text` | `#68879A` | Icons, large text (AA) |
| `UI/UI Element` | `#68879A` | Generic UI elements (same value as UI/05) |
| `UI/06 Low Contrast Text` | `#597284` | Secondary text, captions |
| `UI/07 Text` | `#131416` | Primary text |

### 2.2 Blue Primary (brand ramp)

| Token | Value |
|---|---|
| `Blue Primary/0 Light BG` | `#EEFCFF` |
| `Blue Primary/1` | `#B5EFFC` |
| `Blue Primary/2` | `#7FE1F8` |
| `Blue Primary/3` | `#50D0F2` |
| `Blue Primary/4` | `#29BCEA` |
| **`Blue Primary/5 Primary`** | **`#0CA6DF`** ⭐ |
| `Blue Primary/6` | `#0092D2` |
| `Blue Primary/7` | `#007EC2` |
| `Blue Primary/8` | `#0068AD` |
| `Blue Primary/9` | `#005397` |
| `Blue Primary/10 AAA Text` | `#004080` |

### 2.3 Semantic — Success / Caution / Warning / Critical

| Token | Value |
|---|---|
| `Green Success/01 Light BG` | `#E6F6F0` |
| `Green Success/02 Light Green` | `#1ACD64` |
| `Green Success/03 Normal Green` | `#09A969` |
| `Green Success/04 Dark Green` | `#059669` |
| `Green Success/05 AAA Text` | `#035A3F` |
| `Green Success/06 NEXT Green` | `#63BE00` |
| `Yellow Caution/01 Light BG` | `#FDF2DC` |
| `Yellow Caution/02 Light Yellow` | `#FFCD4E` |
| `Yellow Caution/03 Normal Yellow` | `#F1AB16` |
| `Yellow Caution/04 Dark Yellow` | `#E4960F` |
| `Yellow Caution/05 AAA Text` | `#DD7D1D` |
| `Orange Warning/01 Light BG` | `#FCEDE0` |
| `Orange Warning/02 Light Orange` | `#FC9849` |
| `Orange Warning/03 Normal Orange` | `#E76600` |
| `Orange Warning/04 Dark Orange` | `#D74800` |
| `Orange Warning/05 AAA Text` | `#AF1B09` |
| `Red Critical/01 Light BG` | `#FBE6E9` |
| `Red Critical/02 Light Red` | `#F12D3E` |
| `Red Critical/03 Normal Red` | `#DC061E` |
| `Red Critical/04 Dark Red` | `#B00B13` |
| `Red Critical/05 AAA Text` | `#990F12` |

**Usage rule:** Use `01 Light BG` for banner/badge backgrounds, `03 Normal` for icons and primary fills, and `05 AAA Text` for text placed on a Light BG surface to meet AAA contrast.

### 2.4 Branding

| Token | Value |
|---|---|
| `Branding Color/Electric Blue` | `#003CC8` |
| `Branding Color/Branding Black` | `#000000` |
| `Bright Electric Blue/BEB Normal ⭐️` | `#28DCDC` |

### 2.5 Project colors (solid)

Per-service colors. Use only for that service's cards, icons, and headers — never as semantic colors.

| Project | Value | Project | Value |
|---|---|---|---|
| PromptPay | `#012B5F` | G-Wallet | `#17BF63` |
| Welfare Card | `#4EAEDC` | E-Money | `#F2CB3B` |
| Digital Wallet | `#D9000D` | Gas LPG | `#26A69A` |
| Gas LPG Tag | `#14C9AF` | KLK | `#2EAABB` |
| KLK-plus | `#1140B7` | GLO | `#16499B` |
| YCYD | `#013E9F` | PGLS | `#FF7861` |
| RTDG | `#FDAC2B` | TTT | `#4EAEDC` |
| PointPay | `#BB9759` | Termboon | `#1C8DF5` |
| Termsook | `#DE4016` | WinSave | `#F27043` |
| BMA | `#00744B` | MassTransit | `#6A3A3A` |
| ATK Covid | `#3D985D` | Food Delivery | `#3B3D5B` |
| KTB near home | `#E87D30` | PTP Credit Card | `#2B77FF` |

### 2.6 Gradients

Gradient tokens exist in Figma but cannot be exported as a single hex value. Reference them directly from Figma or convert them to CSS `linear-gradient` at implementation time.

- **Core:** `Gradient/Blue Primary`, `Gradient/Light Blue Primary`, `Gradient/Dark Blue`, `Gradient/Light Blue Pastel`, `Gradient/Green Success`, `Gradient/Yellow Caution`, `Gradient/Orange Warning`, `Gradient/Light Orange Warning`, `Gradient/Red Critical`, `Gradient/Mint Gradient Lighter`, `Gradient/BEB Gradient Line`, `Gradient/Spinner`
- **Project Gradient:** Welfare Card, Welfare Gas, GLO, KLK, KLK-plus, PromptPay, PointPay, PGLS, YCYD, RTDG, Digital Wallet, E-Money, PTP Credit Card, MassTransit, WinSave, ATK Covid, Food Delivery, TTT, Termboon, Termsook, BMA, KTB near home
- **Project Gradient Button:** PromptPay, MassTransit, ATK Covid, Welfare Gas, Welfare Card, PointPay, YCYD, PGLS, WinSave, KLK, KLK-plus, Termboon, Termsook, BMA, Digital Wallet
- **Empty State:** `Empty State/00 BG`, `00 Base Shadow`, `01`–`05`, `Fading`

---

## 3. Typography

Font family: **Kanit** — line-height 100, letter-spacing 0 across all styles.

| Token | Size | Weight | Style |
|---|---|---|---|
| `48/SemiBold` | 48 | 600 | SemiBold |
| `40/SemiBold` | 40 | 600 | SemiBold |
| `32/SemiBold` | 32 | 600 | SemiBold |
| `32/Medium` | 32 | 500 | Medium |
| `28/SemiBold` | 28 | 600 | SemiBold |
| `24/SemiBold` | 24 | 600 | SemiBold |
| `24/Regular` | 24 | 400 | Regular |
| `20/SemiBold` | 20 | 600 | SemiBold |
| `20/Medium` | 20 | 500 | Medium |
| `18/SemiBold` | 18 | 600 | SemiBold |
| `18/Regular` | 18 | 400 | Regular |
| `16 - Normal Text/SemiBold` | 16 | 600 | SemiBold |
| `16 - Normal Text/Medium` | 16 | 500 | Medium |
| `16 - Normal Text/Regular` | 16 | 400 | Regular |
| `14/SemiBold` | 14 | 600 | SemiBold |
| `14/Medium` | 14 | 500 | Medium |
| `14/Regular` | 14 | 400 | Regular |
| `13/SemiBold` | 13 | 600 | SemiBold |
| `13/Medium` | 13 | 500 | Medium |
| `13/Regular` | 13 | 400 | Regular |
| `12/SemiBold` | 12 | 600 | SemiBold |
| `12/Medium` | 12 | 500 | Medium |
| `12/Regular` | 12 | 400 | Regular |

**Base body text = `16 - Normal Text/Regular`**

### G-Board (keyboard mock — Roboto)

| Token | Size | Weight |
|---|---|---|
| `G-Board/Large` | 23 | 400 |
| `G-Board/Default` | 15 | 500 |
| `G-Board/Small` | 13 | 400 |
| `G-Board/Tiny` | 10 | 700 |

G-Board-specific colors: `#000000`, `#3D3D3F`, `#4C4C4C`, `#666666`, `#CCCED5`, `#E8EAED`, `#FFFFFF`

---

## 4. Effects (shadow)

| Token | Definition | Usage |
|---|---|---|
| `Shadow S` | `0 4 12` blur, `#1314160A` | Lightweight cards |
| `Shadow SS` | `0 4 8 #13141614` + `0 0 1 #1314163D` | Cards needing a crisp edge |
| `Shadow M` | `0 4 12` blur, `#13141614` | Standard cards |
| `Shadow L` | `0 8 16` blur, `#1314161F` | Modals, bottom sheets |
| `Shadow XL` | `0 12 16` blur, `#1314162E` | Top-level overlays |
| `Shadow - Upper` | `0 -4 16` blur, `#1314160F` | Bottom bars (upward-facing shadow) |
| `Shadow - Toggle Button` | `0 1 2` blur, spread 1, `#5972843D` | Toggle knob |
| `Shadow - Inner Shadow` | Inner `0 1 2`, `#1314161F` | Pressed / inset input fields |
| `Field - Focus State` | `0 0 0` spread 2, `#0CA6DF3D` | Input focus ring |
| `Default Shadow 10` | `0 12 24` blur, spread -8, `#0000001A` | Generic default shadow |
| `G-Board/Key Box Shadow` | `0 1 0`, `#00000045` | Keyboard keys |

---

## 5. Spacing

Only one spacing variable is declared in Figma: `Space-32px` = `32`

> **Open question:** The rest of the spacing scale (4 / 8 / 12 / 16 / 24) has not been tokenized. These should be added as variables so engineering can reference tokens instead of hardcoding values.

---

## 6. Icon style

> **Frame:** `Icons` (`1940:13894`) — 1096×1965

### 6.1 Foundation

**Local override, v07.0.1:** Team feedback says 2 px feels too heavy in small
composite icons and 24 px is the normal UI default. Start new concepts/revisions
at **1.5 px stroke on a 24×24 canvas** and judge at actual 24 px size. The 1.5 px
value is the proposed lighter baseline, pending the team's next visual test.
This overrides the inherited 2 px guideline for this workflow; it does not claim
that the live Figma library changed. Match an explicitly requested existing
2 px family when that is the task, and do not rewrite unrelated library assets.

| Property | Value |
|---|---|
| Icon library | **Feather** + **EVA Icons** |
| Grid / canvas | **24 × 24 px** |
| Stroke weight | **1.5 px starting weight at 24 px** — local v07.0.1 override; same weight for primary and modifier |
| Stroke cap / join | Round |
| Fill | Use `currentColor` — color comes from tokens, never hardcoded in the SVG |
| Max objects | **2 semantic units by default** — 1 primary + 1 modifier; report repeated visible instances separately (composition §B) |
| Knockout clearance | **1.5 px** minimum transparent ink-to-ink clearance (24 grid ÷ 16); trim rear paths and account for caps/joins (composition §C) |
| Modifier size | Start at 40–55% of the primary’s actual long ink side (6.4–8.8 px for a 16 px primary); adjust with size review, bottom-right by default |

> Historical snapshot quote, superseded by the local override above for new work:
> "Feather and EVA Icons at 24px height and width with 2px stroke weight".
> The live Figma file has not been re-verified for this change.

### 6.2 Keyline shapes

The Icons page includes two keyline shapes (**square** and **diamond**) as guides for drawing new icons with consistent optical size. Every new icon must be aligned to a keyline before it is added to the library.

v07 local baseline geometry on the 24 px grid (global §1), not independently verified as values from the live Figma file:

| Keyline | Thai | Size | Ink bounds | Radius |
|---|---|---|---|---|
| **Circle** | ทรงกลม | Ø 20 | centre (12,12), r 10 | — |
| **Square** | สี่เหลี่ยมจัตุรัส | 18 × 18 | 3 → 21 | 2 |
| **Horizon** | สี่เหลี่ยมผืนผ้าแนวนอน | 20 × 16 | x 2 → 22, y 4 → 20 | 2 |
| **Vertical** | สี่เหลี่ยมผืนผ้าแนวตั้ง | 16 × 20 | x 4 → 20, y 2 → 22 | 2 |
| Live area | — | 20 × 20 | 2 → 22 | — |

The Figma page also draws a **diamond** — treat it as an optical guide for
pointed shapes, not a fifth keyline. Every primary is still fitted to one of the
four above (global §1).

**v07 construction policy:** Fit the primary’s pre-cut silhouette to the active keyline and center it on (12,12); begin with a 2 px inset for an outside modifier. The modifier may exceed the primary keyline, but **all ink must stay inside the live area**. Global §1 owns the fitting and centering procedure; composition §C owns cuts. Deliver a separate keyline overlay. These are local skill policies, not newly verified Figma declarations.

### 6.3 Icon categories

| Category | Style | When to use |
|---|---|---|
| **Menu** | Outline + Filled (Blue Primary) | Main menu / navigation — filled indicates active state |
| **Outline** | Start at 1.5 px stroke at 24 px (§6.1 local override) | General-purpose icons |
| **Solid** | Filled | Status, feedback, alerts — carries more visual weight than outline |
| **Illustrative** | Multi-color | Expressive / promotional icons; multiple colors allowed |
| **System** | Outline | Spinner, loading dots, redirect |
| **Large Size with Background** | Filled on a solid circle | Emphasis icons (feature highlights) |
| **Facilities** | Outline | Facility / merchant category icons |

### 6.4 Naming convention

```
<Style>/<Icon Name>
```

- `Outline/Eye`, `Outline/QR Code`, `Outline/Arrow Left`, `Outline/Notification Off`
- `Solid/Checkmark`, `Solid/Alert Triangle`, `Solid/Play Circle`
- `Asset/<name>` for logos and brand marks, e.g. `Asset/PTP`, `Asset/Tag New`

**Outline ↔ Solid pairs:** Icons that exist in both styles must share the same name (e.g. `Outline/Alert Triangle` / `Solid/Alert Triangle`) so states can be swapped cleanly.

### 6.5 Icon sizes in use

| Size | Usage |
|---|---|
| **24 × 24** | Default — buttons, lists, headers, inputs |
| **40 × 40** | Icons in dialogs / feedback |
| **48 × 48** | Large icons in sheets / success states |
| **56 × 56** | Placeholder / menu tiles |

### 6.6 Icon component variants

Components that contain icons use these standard properties:

- **Position:** `Icon - Left` / `Icon - Right` / `Icon - None`
- **Stepper:** `Icon=Plus|Minus`, `Style=Outline|Filled`, `State=Active|Disabled`
- **Icon Button w Label** — icon with a label underneath

### 6.7 Do / Don't

- ✅ Start new 24 px outline work at 1.5 px (§6.1); keep primary/modifier weights consistent and recalculate cuts when weight changes
- ✅ Scale from the 24 px grid while preserving optical weight
- ✅ Use token colors (`UI/UI Element`, `Blue Primary/5`, semantic colors)
- ❌ Don't mix outline and solid icons within the same group
- ❌ Don't substitute an Illustrative icon for a functional one
- ❌ Don't let final ink exceed the live area; use the keyline as the primary fitting guide

---

## 7. Illustration style

> **Frame:** `Illustrations` (`4355:34985`) — 1680×5850

### 7.1 Visual style

- **Approach:** Semi-flat / soft 3D — flat shapes with subtle gradients and soft shadows, no heavy outlines
- **Color tone:** Grey-blue base drawn from the UI scale (`UI/01`–`UI/05`), accented with Blue Primary
- **Status accent:** A small circle in the lower-right of the illustration, colored with a semantic token — green (success), orange/yellow (warning), red (error), blue (informational)
- **Gradient tokens:** `Empty State/00 BG`, `00 Base Shadow`, `01`–`05`, `Fading` are the dedicated illustration gradients — no ad-hoc colors

### 7.2 Illustration categories & sizes

| Category | Size | When to use |
|---|---|---|
| **Placeholder Large** | 240 × 168 | Image stand-in during design (large slot) |
| **Placeholder Small** | 168 × 168 | Image stand-in (small slot) |
| **Empty State** | 240 × 168 | Screens with no data |
| **Informative (Large)** | 240 × 168 | Dialogs / bottom sheets conveying info or confirmation |
| **Informative (Small)** | 168 × 168 | Sub-steps such as face scan, PIN, card scanning |
| **Onboarding** | 260 × 180 | Onboarding sets (QR PromptPay, PointPay — 3 images each) |
| **Product Highlight** | 240 × 168 · BG 360 × 270 | Product promotion with a dedicated background |
| **Pending Document** | 328 × 99 | Pending-document banner |
| **Display Visual** | 328 × 206 | Card / document visuals (e.g. Citizen Card) |
| **Payment Method** | Template 360 × 440 | Payment channel visuals (EveryPay, PointPay, PlazaPay) |
| **Asset** | Varies | Logos and marks (`Asset/PTP` 62×32, `Asset/PTP CDC` 126×32, `Asset/Tag New` 47×20) |

> **Core ratios:** 240 × 168 (≈ 10:7) for landscape illustrations and 168 × 168 (1:1) for square ones.

### 7.3 Empty State set

`No Data` · `No Email` · `No QR` · `No Transaction` · `No Date Selected` · `No Notification` · `No Product for Search` · `No Product in Store` · `No Address` · `Block Function Temporary` · `Null`

Pair these with **Empty State Contents** (headline + description). The illustration is centered with the spacing above the text defined by the template.

### 7.4 Informative set

- **Large:** Verify by Paotang, Verify by OTP, Open/Close Credit Card, Loading, Notification On/Off, Deep Link – Web/App, Change Account QR Alert, Save PIN
- **Small:** Face Scan Tutorial, PIN Confirmation, Face Scan Open/Closed Eyes, How to Scan Citizen Card, How to Scan Welfare Card

### 7.5 Naming convention

```
<Category>/<Descriptive Name>
```

`Empty State/No Data` · `Informative/Verify by OTP` · `Onboarding/Qr 1` · `Product Highlight/Credit Card` · `Display Visual/Citizen Card` · `Asset/PTP`

Sequential sets use a trailing index (`Qr 1`, `Qr 2`, `Qr 3`).

### 7.6 Do / Don't

- ✅ Use the size defined for each category — don't crop or stretch
- ✅ Use only the Empty State gradient tokens
- ✅ Export as SVG (or PNG @2x/@3x when gradients are complex)
- ❌ Don't use an illustration in place of an icon, or vice versa
- ❌ Don't recolor illustrations to match individual screens
- ❌ Don't place an illustration wider than 240 px on a 360 px viewport

---

## 8. Components in the file

The 📐Design System page contains these main groups:

- **Buttons** — multiple variants (the largest area on the page)
- **Toggle** — variants `On (On/Off)` × `Disabled (True/False)`, 4 states total, 48×24
- **Text Link** — `Normal` / `Pressed` states, with the rule "Pressed on Text is used for Text Links inside Content" plus examples on Button, on Text, and in Content
- **Page Header** — 360×46, composed of `Outline/Arrow Left` (24×24), `Page Title`, and `Text Link`
- **Android Status Bar** — 360×24
- **Camera Shutter**
- **Icons** — naming pattern `Outline/<name>`, e.g. `Outline/Arrow Left`

> Design viewport: **360 px** (mobile)

---

## 9. Naming convention (tokens)

```
<Category>/<Level or Variant> <Description>
```

Examples: `Blue Primary/5 Primary`, `UI/03 Border, Line`, `Red Critical/05 AAA Text`

- The leading number indicates depth on the ramp (0 = lightest)
- The trailing words state usage intent, e.g. `Light BG`, `AAA Text`, `Border, Line`
- Typography uses `<size>/<weight>`
- Icons use `<Style>/<Icon Name>`, e.g. `Outline/Arrow Left`

---

## 10. Open questions / TODO

- [ ] Spacing scale is incomplete — only `Space-32px` exists
- [ ] Gradient tokens need real values exported as CSS/JSON
- [ ] Border radius has not been tokenized
- [ ] Duplicate values: `UI/05 Graphics, Large AA Text` and `UI/UI Element` are both `#68879A` — merge them or clarify their distinct usage
- [ ] Out-of-system tokens remain (`Settings first title #222222`, `Secondary color #686868`, `Color/Fill/Greyscale/*`, `wireframes/*`, `material-theme/*`, `Sticky/Positive`) — verify whether they're still in use or should be removed
- [ ] Icons: sizes (24/40/48/56) are not defined as variables
- [ ] Icons: verify that every icon with an Outline/Solid pair uses matching names
- [ ] Illustrations: Empty State gradient tokens have no exportable values — spec them as CSS/JSON
- [ ] Illustrations: no dark mode guideline yet
