# Projects — Per-Product Design System Files

Each file here is the **design-system source of truth for one product**. The
skill reuses the selected project within the same job and reads the relevant
icon sections. Ask only when the project is unknown or changes. Nothing in this folder is loaded by default.

## Available projects

| File | Product | Grid / stroke | Icon naming | Notes |
|---|---|---|---|---|
| `TungNgern.md` | TungNgern (ถุงเงิน) — Krungthai Bank | 24×24 / 1.5 px starting stroke, round cap+join | `<Style>/<Icon Name>` | Local v07.0.1 stroke override; inherited Figma snapshot recorded 2 px; Outline↔Solid pairs share a name |

*(no project selected = global defaults only — see Precedence below)*

---

## Precedence

When values conflict, higher wins:

1. **What the user states in this conversation**, then supplied task-specific icon guidelines — explicit choices win.
2. **The selected project file in this folder** — grid, stroke, terminals, joins,
   color tokens, naming, sizes, categories, Do/Don't.
3. **`references/iconography-design-ref.md`** and
   **`references/composition-language-ref.md`** — global defaults for anything
   the project file leaves unspecified, including the default 2-semantic-unit budget and
   `grid ÷ 16` minimum ink clearance (1.5 px at 24 px). A project may state its own
   knockout value or object rules; where it does, the project wins.
4. **Convention research** (`references/magnific-icon-style-lookup.md`) — never
   authoritative. Convention research only.

If a project file contradicts the global reference, **follow the project file
and say so out loud** in the delivery notes — don't silently pick one. The most
common real conflict is naming: the global reference specifies kebab-case
`[object]-[variant]-[state]`, while a project may define its own pattern (e.g.
TungNgern uses `Outline/Arrow Left`). The project pattern wins.

Also flag any **open questions / TODOs** in a project file that touch the icon
being drawn — e.g. if icon sizes aren't tokenized yet, that's worth surfacing
rather than assuming a value.

---

## Adding a new project

Drop a `<ProductName>.md` in this folder and add a row to the table above. It
does not need every section, but the skill looks for these:

```markdown
# Design System — <Product>

> **Source:** <Figma URL>
> **Node:** `<node-id>`
> **Last synced:** YYYY-MM-DD

## Color tokens
<!-- token name → value → usage -->

## Typography
<!-- font family, size/weight tokens -->

## Icon style
<!-- REQUIRED for this skill:
     - icon library / base set
     - grid size
     - stroke weight
     - cap + join style
     - fill/color rule (token vs hardcoded)
     - keyline shapes available
     - icon categories and when to use each
     - naming convention
     - sizes in use
     - object-count / composition rules, if they differ from the 2-object
       ceiling and the `grid ÷ 16` knockout clearance
     - Do / Don't -->

## Illustration style
<!-- only if the product distinguishes icons from illustrations -->

## Open questions / TODO
```

The **Icon style** section is the part the skill actually depends on. A project
file without it will fall back to global defaults for everything missing, which
is usually not what anyone wants.

If the project's Figma file is reachable (via the Figma MCP), fetch it and
compare against the written file — guidelines drift out of sync with what's
actually shipped. Flag mismatches to the user rather than picking one silently
(SKILL.md, Scope and reference routing).
